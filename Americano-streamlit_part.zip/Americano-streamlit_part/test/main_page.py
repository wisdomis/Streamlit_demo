import streamlit as st
import AutoRegression as AR
import pandas as pd

st.header('AMERICANO')